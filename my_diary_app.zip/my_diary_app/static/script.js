// Функции для работы с календарем
function changeDate(days) {
    const currentDate = new URLSearchParams(window.location.search).get('date');
    const date = new Date(currentDate || new Date());
    date.setDate(date.getDate() + days);

    window.location.href = `{{ url_for('calendar_diary') }}?date=${date.toISOString().split('T')[0]}`;
}

function goToToday() {
    const today = new Date().toISOString().split('T')[0];
    window.location.href = `{{ url_for('calendar_diary') }}?date=${today}`;
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    // Автосохранение для ежедневника
    const diaryTextarea = document.getElementById('diaryContent');
    if (diaryTextarea) {
        diaryTextarea.addEventListener('input', function() {
            localStorage.setItem('diaryDraft', this.value);
        });

        // Восстановление черновика
        const draft = localStorage.getItem('diaryDraft');
        if (draft && !diaryTextarea.value) {
            diaryTextarea.value = draft;
        }
    }
});
