from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import os
import json
from datetime import datetime, date
import markdown

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Папки для хранения данных
NOTES_DIR = 'data/notes'
DIARY_DIR = 'data/diary'
TASKS_DIR = 'data/tasks'

# Создание папок если их нет
os.makedirs(NOTES_DIR, exist_ok=True)
os.makedirs(DIARY_DIR, exist_ok=True)
os.makedirs(TASKS_DIR, exist_ok=True)


@app.route('/')
def index():
    # Получаем последние заметки
    notes = []
    note_files = os.listdir(NOTES_DIR)
    note_files.sort(key=lambda x: os.path.getmtime(os.path.join(NOTES_DIR, x)), reverse=True)

    for filename in note_files[:5]:  # Последние 5 заметок
        if filename.endswith('.md'):
            with open(os.path.join(NOTES_DIR, filename), 'r', encoding='utf-8') as f:
                content = f.read()
            notes.append({
                'filename': filename,
                'title': filename.replace('.md', ''),
                'content': content,
                'preview': content[:100] + '...' if len(content) > 100 else content
            })

    # Получаем невыполненные задачи
    tasks = []
    for filename in os.listdir(TASKS_DIR):
        if filename.endswith('.json'):
            try:
                with open(os.path.join(TASKS_DIR, filename), 'r', encoding='utf-8') as f:
                    task_data = json.load(f)

                if not task_data.get('completed', False):
                    task_data['filename'] = filename
                    task_data['display_date'] = task_data.get('created', '').split('T')[0]
                    tasks.append(task_data)
            except Exception as e:
                print(f"Ошибка при загрузке файла {filename}: {e}")

    # Сортируем задачи по приоритету
    priority_order = {'high': 0, 'medium': 1, 'low': 2}
    tasks.sort(key=lambda x: (priority_order.get(x.get('priority', 'low'), 2), x.get('created', '')))

    return render_template('index.html', notes=notes, tasks=tasks, active_page='index')


@app.route('/quick_task', methods=['POST'])
def quick_task():
    """Создание быстрой задачи с главной страницы"""
    title = request.form.get('title')

    if not title:
        flash('Название задачи обязательно', 'error')
        return redirect(url_for('index'))

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"task_{timestamp}.json"
    filepath = os.path.join(TASKS_DIR, filename)

    task_data = {
        'title': title,
        'description': '',
        'priority': 'medium',
        'completed': False,
        'created': datetime.now().isoformat(),
        'last_modified': datetime.now().isoformat()
    }

    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(task_data, f, ensure_ascii=False, indent=2)

    flash('Задача создана', 'success')
    return redirect(url_for('index'))


@app.route('/toggle_task/<filename>')
def toggle_task(filename):
    """Переключение статуса задачи с любой страницы"""
    filepath = os.path.join(TASKS_DIR, filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            task_data = json.load(f)

        task_data['completed'] = not task_data.get('completed', False)
        task_data['last_modified'] = datetime.now().isoformat()

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(task_data, f, ensure_ascii=False, indent=2)

        return jsonify({'success': True, 'completed': task_data['completed']})

    return jsonify({'success': False})


# БЛОКНОТ - Управление заметками .md
@app.route('/notebook')
def notebook():
    notes = []
    for filename in os.listdir(NOTES_DIR):
        if filename.endswith('.md'):
            with open(os.path.join(NOTES_DIR, filename), 'r', encoding='utf-8') as f:
                content = f.read()
            notes.append({
                'filename': filename,
                'title': filename.replace('.md', ''),
                'content': content,
                'html_content': markdown.markdown(content)
            })
    return render_template('notebook.html', notes=notes, active_page='notebook')


@app.route('/notebook/create', methods=['POST'])
def create_note():
    title = request.form.get('title')
    content = request.form.get('content')

    if not title:
        flash('Название заметки обязательно', 'error')
        return redirect(url_for('notebook'))

    filename = f"{title}.md"
    filepath = os.path.join(NOTES_DIR, filename)

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

    flash('Заметка создана успешно', 'success')
    return redirect(url_for('notebook'))


@app.route('/notebook/delete/<filename>')
def delete_note(filename):
    filepath = os.path.join(NOTES_DIR, filename)
    if os.path.exists(filepath):
        os.remove(filepath)
        flash('Заметка удалена', 'success')
    return redirect(url_for('notebook'))


@app.route('/notebook/edit/<filename>')
def edit_note_page(filename):
    """Страница редактирования заметки"""
    filepath = os.path.join(NOTES_DIR, filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        note = {
            'filename': filename,
            'title': filename.replace('.md', ''),
            'content': content
        }
        return render_template('edit_note.html', note=note, active_page='notebook')

    flash('Заметка не найдена', 'error')
    return redirect(url_for('notebook'))


@app.route('/notebook/update/<filename>', methods=['POST'])
def update_note(filename):
    """Обновление заметки"""
    content = request.form.get('content')
    filepath = os.path.join(NOTES_DIR, filename)

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

    flash('Заметка обновлена', 'success')
    return redirect(url_for('notebook'))


@app.route('/notebook/view/<filename>')
def view_note(filename):
    """Просмотр отдельной заметки"""
    filepath = os.path.join(NOTES_DIR, filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        note = {
            'filename': filename,
            'title': filename.replace('.md', ''),
            'content': content,
            'html_content': markdown.markdown(content)
        }
        return render_template('view_note.html', note=note, active_page='notebook')

    flash('Заметка не найдена', 'error')
    return redirect(url_for('notebook'))


# ЕЖЕДНЕВНИК ЗАВИСИМЫЙ ОТ КАЛЕНДАРЯ
@app.route('/calendar_diary')
def calendar_diary():
    selected_date = request.args.get('date', date.today().isoformat())
    diary_file = os.path.join(DIARY_DIR, f"{selected_date}.json")

    entry = {}
    if os.path.exists(diary_file):
        with open(diary_file, 'r', encoding='utf-8') as f:
            entry = json.load(f)

    return render_template('calendar_diary.html',
                           selected_date=selected_date,
                           entry=entry,
                           active_page='calendar_diary')


@app.route('/calendar_diary/save', methods=['POST'])
def save_calendar_entry():
    date_str = request.form.get('date')
    title = request.form.get('title')
    content = request.form.get('content')

    diary_file = os.path.join(DIARY_DIR, f"{date_str}.json")

    entry_data = {
        'title': title,
        'content': content,
        'last_modified': datetime.now().isoformat()
    }

    with open(diary_file, 'w', encoding='utf-8') as f:
        json.dump(entry_data, f, ensure_ascii=False, indent=2)

    flash('Запись сохранена', 'success')
    return redirect(url_for('calendar_diary', date=date_str))


# ЗАДАЧНИК
@app.route('/tasks')
def tasks():
    tasks = []
    for filename in os.listdir(TASKS_DIR):
        if filename.endswith('.json'):
            try:
                with open(os.path.join(TASKS_DIR, filename), 'r', encoding='utf-8') as f:
                    task_data = json.load(f)

                task_data['filename'] = filename
                task_data['display_date'] = task_data.get('created', '').split('T')[0]
                tasks.append(task_data)
            except Exception as e:
                print(f"Ошибка при загрузке файла {filename}: {e}")

    # Сортировка по статусу и дате создания
    tasks.sort(key=lambda x: (x.get('completed', False), x.get('created', '')), reverse=False)
    return render_template('tasks.html', tasks=tasks, active_page='tasks')


@app.route('/tasks/create', methods=['POST'])
def create_task():
    title = request.form.get('title')
    description = request.form.get('description', '')
    priority = request.form.get('priority', 'medium')

    if not title:
        flash('Название задачи обязательно', 'error')
        return redirect(url_for('tasks'))

    # Создаем уникальное имя файла на основе timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"task_{timestamp}.json"
    filepath = os.path.join(TASKS_DIR, filename)

    task_data = {
        'title': title,
        'description': description,
        'priority': priority,
        'completed': False,
        'created': datetime.now().isoformat(),
        'last_modified': datetime.now().isoformat()
    }

    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(task_data, f, ensure_ascii=False, indent=2)

    flash('Задача создана', 'success')
    return redirect(url_for('tasks'))


@app.route('/tasks/delete/<filename>')
def delete_task(filename):
    filepath = os.path.join(TASKS_DIR, filename)
    if os.path.exists(filepath):
        os.remove(filepath)
        flash('Задача удалена', 'success')
    return redirect(url_for('tasks'))


if __name__ == '__main__':
    app.run(debug=True)
