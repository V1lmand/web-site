// Функции для работы с календарем
function changeDate(days) {
    const currentDate = new URLSearchParams(window.location.search).get('date');
    const date = new Date(currentDate || new Date());
    date.setDate(date.getDate() + days);

    window.location.href = `{{ url_for('calendar_diary') }}?date=${date.toISOString().split('T')[0]}`;
}

function goToToday() {
    const today = new Date().toISOString().split('T')[0];
    window.location.href = `{{ url_for('calendar_diary') }}?date=${today}`;
}

// Функции для модального окна задач
function openCreateTaskModal() {
    const modal = document.getElementById('createTaskModal');
    if (modal) {
        modal.style.display = 'block';

        // Установка минимальной даты как сегодняшней
        const today = new Date().toISOString().split('T')[0];
        const dateInput = document.getElementById('modal_due_date');
        if (dateInput) {
            dateInput.setAttribute('min', today);
            // Очистка значения даты при открытии
            dateInput.value = '';
        }

        document.getElementById('modal_title').focus();
    }
}

function closeCreateTaskModal() {
    const modal = document.getElementById('createTaskModal');
    if (modal) {
        modal.style.display = 'none';
        // Очистка формы при закрытии
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
        }
    }
}

// Функция для форматирования даты
function formatDateForInput(date) {
    if (!date) return '';
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Универсальное закрытие модального окна при клике вне его
window.onclick = function(event) {
    const modal = document.getElementById('createTaskModal');
    if (modal && event.target === modal) {
        closeCreateTaskModal();
    }
}

// Универсальное закрытие модального окна по ESC
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeCreateTaskModal();
    }
});

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    // Установка минимальной даты для всех полей date
    const dateInputs = document.querySelectorAll('input[type="date"]');
    const today = new Date().toISOString().split('T')[0];

    dateInputs.forEach(input => {
        if (!input.getAttribute('min')) {
            input.setAttribute('min', today);
        }
    });

    // Автосохранение для ежедневника
    const diaryTextarea = document.getElementById('diaryContent');
    if (diaryTextarea) {
        diaryTextarea.addEventListener('input', function() {
            localStorage.setItem('diaryDraft', this.value);
        });

        // Восстановление черновика
        const draft = localStorage.getItem('diaryDraft');
        if (draft && !diaryTextarea.value) {
            diaryTextarea.value = draft;
        }
    }

    // Проверка поддержки input type="date"
    checkDateInputSupport();
});

// Проверка поддержки type="date" и fallback
function checkDateInputSupport() {
    const input = document.createElement('input');
    input.setAttribute('type', 'date');
    const notSupported = input.type === 'text';

    if (notSupported) {
        console.warn('Браузер не поддерживает input type="date"');
        addDateInputFallback();
    }
}

function addDateInputFallback() {
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        input.setAttribute('placeholder', 'дд.мм.гггг');
        input.setAttribute('pattern', '\\d{2}\\.\\d{2}\\.\\d{4}');
        input.setAttribute('title', 'Формат: дд.мм.гггг');
    });
}

// Функция очистки даты (опционально)
function clearDate() {
    const dateInput = document.getElementById('modal_due_date');
    if (dateInput) {
        dateInput.value = '';
    }
}
