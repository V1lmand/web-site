function changeDate(days) {
    const currentDate = new URLSearchParams(window.location.search).get('date');
    const date = new Date(currentDate || new Date());
    date.setDate(date.getDate() + days);

    window.location.href = `{{ url_for('calendar_diary') }}?date=${date.toISOString().split('T')[0]}`;
}

function goToToday() {
    const today = new Date().toISOString().split('T')[0];
    window.location.href = `{{ url_for('calendar_diary') }}?date=${today}`;
}

function openCreateTaskModal() {
    const modal = document.getElementById('createTaskModal');
    if (modal) {
        modal.style.display = 'block';

        const today = new Date().toISOString().split('T')[0];
        const dateInput = document.getElementById('modal_due_date');
        if (dateInput) {
            dateInput.setAttribute('min', today);
            dateInput.value = '';
        }

        document.getElementById('modal_title').focus();
    }
}

function closeCreateTaskModal() {
    const modal = document.getElementById('createTaskModal');
    if (modal) {
        modal.style.display = 'none';
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
        }
    }
}

function formatDateForInput(date) {
    if (!date) return '';
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

window.onclick = function(event) {
    const modal = document.getElementById('createTaskModal');
    if (modal && event.target === modal) {
        closeCreateTaskModal();
    }
}

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeCreateTaskModal();
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const dateInputs = document.querySelectorAll('input[type="date"]');
    const today = new Date().toISOString().split('T')[0];

    dateInputs.forEach(input => {
        if (!input.getAttribute('min')) {
            input.setAttribute('min', today);
        }
    });

    const diaryTextarea = document.getElementById('diaryContent');
    if (diaryTextarea) {
        diaryTextarea.addEventListener('input', function() {
            localStorage.setItem('diaryDraft', this.value);
        });

        const draft = localStorage.getItem('diaryDraft');
        if (draft && !diaryTextarea.value) {
            diaryTextarea.value = draft;
        }
    }

    checkDateInputSupport();
});

function checkDateInputSupport() {
    const input = document.createElement('input');
    input.setAttribute('type', 'date');
    const notSupported = input.type === 'text';

    if (notSupported) {
        console.warn('Браузер не поддерживает input type="date"');
        addDateInputFallback();
    }
}

function addDateInputFallback() {
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        input.setAttribute('placeholder', 'дд.мм.гггг');
        input.setAttribute('pattern', '\\d{2}\\.\\d{2}\\.\\d{4}');
        input.setAttribute('title', 'Формат: дд.мм.гггг');
    });
}

// Функция очистки даты (опционально)
function clearDate() {
    const dateInput = document.getElementById('modal_due_date');
    if (dateInput) {
        dateInput.value = '';
    }
}
