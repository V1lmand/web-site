from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import os
import json
from datetime import datetime, date
import markdown

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

NOTES_DIR = 'data/notes'
DIARY_DIR = 'data/diary'
TASKS_DIR = 'data/tasks'
TASKS_FOLDER = 'tasks'
os.makedirs(NOTES_DIR, exist_ok=True)
os.makedirs(DIARY_DIR, exist_ok=True)
os.makedirs(TASKS_DIR, exist_ok=True)
if not os.path.exists(TASKS_FOLDER):
    os.makedirs(TASKS_FOLDER)

@app.route('/')
def index():
    notes = []
    note_files = os.listdir(NOTES_DIR)
    note_files.sort(key=lambda x: os.path.getmtime(os.path.join(NOTES_DIR, x)), reverse=True)

    for filename in note_files[:5]:
        if filename.endswith('.md'):
            with open(os.path.join(NOTES_DIR, filename), 'r', encoding='utf-8') as f:
                content = f.read()
            notes.append({
                'filename': filename,
                'title': filename.replace('.md', ''),
                'content': content,
                'preview': content[:100] + '...' if len(content) > 100 else content
            })

    tasks = []
    for filename in os.listdir(TASKS_DIR):
        if filename.endswith('.json'):
            try:
                with open(os.path.join(TASKS_DIR, filename), 'r', encoding='utf-8') as f:
                    task_data = json.load(f)

                if not task_data.get('completed', False):
                    task_data['filename'] = filename
                    task_data['display_date'] = task_data.get('created', '').split('T')[0]
                    tasks.append(task_data)
            except Exception as e:
                print(f"Ошибка при загрузке файла {filename}: {e}")

    priority_order = {'high': 0, 'medium': 1, 'low': 2}
    tasks.sort(key=lambda x: (priority_order.get(x.get('priority', 'low'), 2), x.get('created', '')))

    return render_template('index.html', notes=notes, tasks=tasks, active_page='index')


@app.route('/quick_task', methods=['POST'])
def quick_task():
    title = request.form.get('title')

    if not title:
        flash('Название задачи обязательно', 'error')
        return redirect(url_for('index'))

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"task_{timestamp}.json"
    filepath = os.path.join(TASKS_DIR, filename)

    task_data = {
        'title': title,
        'description': '',
        'priority': 'medium',
        'completed': False,
        'created': datetime.now().isoformat(),
        'last_modified': datetime.now().isoformat()
    }

    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(task_data, f, ensure_ascii=False, indent=2)

    flash('Задача создана', 'success')
    return redirect(url_for('index'))


@app.route('/toggle_task/<filename>')
def toggle_task(filename):
    filepath = os.path.join(TASKS_DIR, filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            task_data = json.load(f)

        task_data['completed'] = not task_data.get('completed', False)
        task_data['last_modified'] = datetime.now().isoformat()

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(task_data, f, ensure_ascii=False, indent=2)

        return jsonify({'success': True, 'completed': task_data['completed']})

    return jsonify({'success': False})


@app.route('/notebook')
def notebook():
    notes = []
    for filename in os.listdir(NOTES_DIR):
        if filename.endswith('.md'):
            with open(os.path.join(NOTES_DIR, filename), 'r', encoding='utf-8') as f:
                content = f.read()
            notes.append({
                'filename': filename,
                'title': filename.replace('.md', ''),
                'content': content,
                'html_content': markdown.markdown(content)
            })
    return render_template('notebook.html', notes=notes, active_page='notebook')


@app.route('/notebook/create', methods=['POST'])
def create_note():
    title = request.form.get('title')
    content = request.form.get('content')

    if not title:
        flash('Название заметки обязательно', 'error')
        return redirect(url_for('notebook'))

    filename = f"{title}.md"
    filepath = os.path.join(NOTES_DIR, filename)

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

    flash('Заметка создана успешно', 'success')
    return redirect(url_for('notebook'))


@app.route('/notebook/delete/<filename>')
def delete_note(filename):
    filepath = os.path.join(NOTES_DIR, filename)
    if os.path.exists(filepath):
        os.remove(filepath)
        flash('Заметка удалена', 'success')
    return redirect(url_for('notebook'))


@app.route('/notebook/edit/<filename>')
def edit_note_page(filename):
    filepath = os.path.join(NOTES_DIR, filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        note = {
            'filename': filename,
            'title': filename.replace('.md', ''),
            'content': content
        }
        return render_template('edit_note.html', note=note, active_page='notebook')

    flash('Заметка не найдена', 'error')
    return redirect(url_for('notebook'))


@app.route('/notebook/update/<filename>', methods=['POST'])
def update_note(filename):
    content = request.form.get('content')
    filepath = os.path.join(NOTES_DIR, filename)

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

    flash('Заметка обновлена', 'success')
    return redirect(url_for('notebook'))


@app.route('/notebook/view/<filename>')
def view_note(filename):
    filepath = os.path.join(NOTES_DIR, filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        note = {
            'filename': filename,
            'title': filename.replace('.md', ''),
            'content': content,
            'html_content': markdown.markdown(content)
        }
        return render_template('view_note.html', note=note, active_page='notebook')

    flash('Заметка не найдена', 'error')
    return redirect(url_for('notebook'))


@app.route('/calendar_diary')
def calendar_diary():
    selected_date = request.args.get('date', date.today().isoformat())
    diary_file = os.path.join(DIARY_DIR, f"{selected_date}.json")

    entry = {}
    if os.path.exists(diary_file):
        with open(diary_file, 'r', encoding='utf-8') as f:
            entry = json.load(f)

    return render_template('calendar_diary.html',
                           selected_date=selected_date,
                           entry=entry,
                           active_page='calendar_diary')


@app.route('/calendar_diary/save', methods=['POST'])
def save_calendar_entry():
    date_str = request.form.get('date')
    title = request.form.get('title')
    content = request.form.get('content')

    diary_file = os.path.join(DIARY_DIR, f"{date_str}.json")

    entry_data = {
        'title': title,
        'content': content,
        'last_modified': datetime.now().isoformat()
    }

    with open(diary_file, 'w', encoding='utf-8') as f:
        json.dump(entry_data, f, ensure_ascii=False, indent=2)

    flash('Запись сохранена', 'success')
    return redirect(url_for('calendar_diary', date=date_str))


def get_tasks():
    tasks = []
    if os.path.exists(TASKS_FOLDER):
        for filename in os.listdir(TASKS_FOLDER):
            if filename.endswith('.json'):
                with open(os.path.join(TASKS_FOLDER, filename), 'r', encoding='utf-8') as f:
                    task_data = json.load(f)
                    task_data['filename'] = filename
                    if 'due_date' in task_data and task_data['due_date']:
                        try:
                            task_data['due_date'] = datetime.strptime(task_data['due_date'], '%Y-%m-%d')
                        except:
                            pass
                    tasks.append(task_data)
    tasks.sort(key=lambda x: x.get('created_at', ''), reverse=True)
    return tasks


def save_task(task_data, filename=None):
    if not filename:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"task_{timestamp}.json"

    task_data['filename'] = filename
    task_data['created_at'] = datetime.now().isoformat()

    with open(os.path.join(TASKS_FOLDER, filename), 'w', encoding='utf-8') as f:
        json.dump(task_data, f, ensure_ascii=False, indent=2)

    return filename


@app.route('/tasks')
def tasks():
    tasks_list = get_tasks()
    return render_template('tasks.html', tasks=tasks_list, active_page='tasks')


@app.route('/create_task', methods=['POST'])
def create_task():
    title = request.form.get('title')
    description = request.form.get('description')
    priority = request.form.get('priority', 'medium')
    due_date = request.form.get('due_date')

    if not title:
        flash('Название задачи обязательно!', 'error')
        return redirect(url_for('tasks'))

    task_data = {
        'title': title,
        'description': description,
        'priority': priority,
        'due_date': due_date,
        'completed': False
    }

    save_task(task_data)
    flash('Задача создана успешно!', 'success')
    return redirect(url_for('tasks'))


@app.route('/edit_task/<filename>')
def edit_task(filename):
    filepath = os.path.join(TASKS_FOLDER, filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            task_data = json.load(f)
        return render_template('edit_task.html', task=task_data, active_page='tasks')
    else:
        flash('Задача не найдена!', 'error')
        return redirect(url_for('tasks'))


@app.route('/update_task/<filename>', methods=['POST'])
def update_task(filename):
    title = request.form.get('title')
    description = request.form.get('description')
    priority = request.form.get('priority', 'medium')
    due_date = request.form.get('due_date')

    filepath = os.path.join(TASKS_FOLDER, filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            task_data = json.load(f)

        task_data.update({
            'title': title,
            'description': description,
            'priority': priority,
            'due_date': due_date
        })

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(task_data, f, ensure_ascii=False, indent=2)

        flash('Задача обновлена!', 'success')

    return redirect(url_for('tasks'))


@app.route('/delete_task/<filename>')
def delete_task(filename):
    filepath = os.path.join(TASKS_FOLDER, filename)
    if os.path.exists(filepath):
        os.remove(filepath)
        flash('Задача удалена!', 'success')
    else:
        flash('Задача не найдена!', 'error')

    return redirect(url_for('tasks'))


@app.route('/complete_all_tasks', methods=['POST'])
def complete_all_tasks():
    tasks_list = get_tasks()

    for task in tasks_list:
        if not task.get('completed', False):
            filepath = os.path.join(TASKS_FOLDER, task['filename'])
            with open(filepath, 'r', encoding='utf-8') as f:
                task_data = json.load(f)

            task_data['completed'] = True

            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(task_data, f, ensure_ascii=False, indent=2)

    flash('Все задачи выполнены!', 'success')
    return redirect(url_for('tasks'))


@app.route('/complete_task/<filename>', methods=['POST'])
def complete_task(filename):
    filepath = os.path.join(TASKS_FOLDER, filename)

    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            task_data = json.load(f)

        if not task_data.get('completed', False):
            task_data['completed'] = True

            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(task_data, f, ensure_ascii=False, indent=2)

            flash('Задача выполнена!', 'success')
        else:
            flash('Задача уже выполнена!', 'info')

    return redirect(url_for('tasks'))

@app.route('/delete_completed_tasks', methods=['POST'])
def delete_completed_tasks():
    tasks_list = get_tasks()
    deleted_count = 0

    for task in tasks_list:
        if task.get('completed', False):
            filepath = os.path.join(TASKS_FOLDER, task['filename'])
            if os.path.exists(filepath):
                os.remove(filepath)
                deleted_count += 1

    flash(f'Удалено {deleted_count} выполненных задач!', 'success')
    return redirect(url_for('tasks'))


if __name__ == '__main__':
    app.run(debug=True)
